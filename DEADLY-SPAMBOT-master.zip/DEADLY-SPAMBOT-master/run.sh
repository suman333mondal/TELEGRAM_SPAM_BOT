python3 -m DEADLYSPAM
